#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

mod afc;
mod airlift;
mod airtraffic;
mod apple;
mod commands;
mod device;
mod flasher;
mod host_guard;
mod i18n;
mod image_skin;
mod keypad;
mod passthm;
mod scanner;
mod store;
mod wallet_backup;

pub const APP_VERSION: &str = env!("CARGO_PKG_VERSION");

fn main() {
    let args: Vec<String> = std::env::args().collect();
    let env_probe = std::env::var("VEYRO_PROBE_ONLY").as_deref() == Ok("1");

    if let Some(valid_args) = probe_command(&args) {
        attach_probe_console();
        if !valid_args {
            eprintln!("Usage: veyro.exe --probe");
            std::process::exit(2);
        }
        run_probe_and_exit();
    }
    if env_probe {
        attach_probe_console();
        run_probe_and_exit();
    }
    if args.len() >= 4 && args[1] == "--flash" {
        exit_with(cli_flash(&args[2], &args[3]));
    }
    if args.len() >= 3 && args[1] == "--save-original" {
        exit_with(cli_save_original(&args[2]));
    }
    if args.len() >= 3 && args[1] == "--restore-original" {
        exit_with(cli_restore_original(&args[2]));
    }
    if args.len() >= 3 && args[1] == "--passcode" {
        let telephony = args.get(3).map(String::as_str);
        let language = args.get(4).map(String::as_str);
        exit_with(cli_passcode(&args[2], telephony, language));
    }

    run_gui();
}

/// Launch the Tauri window that hosts the Veyro web UI.
fn run_gui() {
    tauri::Builder::default()
        .manage(commands::ScanState::default())
        .invoke_handler(tauri::generate_handler![
            commands::engine_status,
            commands::state_get,
            commands::list_devices,
            commands::scan,
            commands::add_manual_card,
            commands::apply_design,
            commands::apply_upload,
            commands::undo_card,
            commands::push_to_phone,
            commands::skin_url,
            commands::open_external,
        ])
        .run(tauri::generate_context!())
        .expect("error while running Veyro");
}

fn exit_with(result: anyhow::Result<()>) -> ! {
    match result {
        Ok(()) => std::process::exit(0),
        Err(e) => {
            eprintln!("Error: {e:#}");
            std::process::exit(1);
        }
    }
}

#[cfg(windows)]
fn attach_probe_console() {
    #[link(name = "kernel32")]
    unsafe extern "system" {
        fn AttachConsole(process_id: u32) -> i32;
    }
    // GUI-subsystem processes have no console by default. Attach only for --probe.
    unsafe { AttachConsole(u32::MAX) };
}

#[cfg(not(windows))]
fn attach_probe_console() {}

fn probe_command(args: &[String]) -> Option<bool> {
    (args.get(1).map(String::as_str) == Some("--probe")).then_some(args.len() == 2)
}

fn run_probe_and_exit() -> ! {
    exit_with(cli_probe())
}

fn warn_blocking_apps() {
    let apps = host_guard::blocking_sync_apps();
    if !apps.is_empty() {
        eprintln!(
            "warning   = quit these first (they steal AirTraffic): {}",
            apps.join(", ")
        );
    }
}

fn first_udid() -> anyhow::Result<String> {
    let devices = device::list_connected_devices()?;
    if devices.is_empty() {
        anyhow::bail!("No iPhone detected via usbmux / Apple Mobile Device Support");
    }
    for d in &devices {
        println!("device    = {d}  udid={}", d.udid);
    }
    Ok(devices[0].udid.clone())
}

fn cli_probe() -> anyhow::Result<()> {
    warn_blocking_apps();
    let mut usb_devices = device::query_usbmux_devices()?
        .into_iter()
        .filter(|d| d.connection_type.eq_ignore_ascii_case("USB"));
    let Some(device) = usb_devices.next() else {
        anyhow::bail!("No USB-connected iPhone found for handshake probe");
    };
    if usb_devices.next().is_some() {
        anyhow::bail!("Multiple USB devices found; probe requires exactly one");
    }
    println!("probe = AirTraffic handshake only; no AFC staging or Wallet asset writes");
    airtraffic::sync_assets_via_airtraffic(&device.udid, &[], |msg| println!("log: {msg}"))?;
    println!("probe DONE — ReadyForSync received");
    Ok(())
}

fn cleanup_books(udid: &str) -> anyhow::Result<()> {
    println!("cleanup   = clearing leftover Books/airlift staging...");
    let session = device::ActiveDeviceSession::open(Some(udid))?;
    let afc = afc::AfcClient::new(&session)?;
    let n = airlift::cleanup_airlift_staging(&afc, |msg| println!("cleanup   = {msg}"));
    println!("cleanup   = {n} leftover path(s) removed");
    Ok(())
}

fn cli_flash(card_hash: &str, image_path: &str) -> anyhow::Result<()> {
    println!("=== Veyro CLI flash ===");
    println!("card_hash = {card_hash}");
    println!("image     = {image_path}");
    warn_blocking_apps();

    let udid = first_udid()?;
    cleanup_books(&udid)?;

    let path = std::path::Path::new(image_path);
    let art = if path
        .extension()
        .and_then(|e| e.to_str())
        .is_some_and(|e| e.eq_ignore_ascii_case("pdf"))
    {
        let pdf = std::fs::read(path)?;
        println!("skin      = raw PDF {} bytes (Suica / transit)", pdf.len());
        flasher::WalletArt::Pdf(pdf)
    } else {
        let skin = image_skin::PreparedSkin::from_path(path)?;
        println!(
            "skin      = {}x{} -> 1536x969 @3x={} bytes, 1024x646 @2x={} bytes",
            skin.source_width,
            skin.source_height,
            skin.png.len(),
            skin.png_2x.len()
        );
        flasher::WalletArt::Png {
            png_3x: skin.png,
            png_2x: skin.png_2x,
        }
    };

    println!("Keep iPhone UNLOCKED, screen ON. Open Books once if prompted.");
    println!("Starting flash...");

    flasher::flash_wallet_skin(
        &udid,
        card_hash,
        &art,
        |step, total, msg| println!("progress [{step}/{total}] {msg}"),
        |msg| println!("log: {msg}"),
    )?;

    println!("DONE — force-close Wallet on iPhone and reopen.");
    Ok(())
}

fn cli_save_original(card_hash: &str) -> anyhow::Result<()> {
    println!("=== Veyro CLI save original ===");
    println!("card_hash = {card_hash}");
    warn_blocking_apps();

    let udid = first_udid()?;
    cleanup_books(&udid)?;
    println!("Keep iPhone UNLOCKED, screen ON. Open Books once if prompted.");
    println!("Exporting original artwork via Airlift (writes each file back)...");

    let saved = flasher::capture_original_artwork(&udid, card_hash, |msg| println!("log: {msg}"))?;
    let dir = wallet_backup::backup_dir(&udid, card_hash);
    println!("DONE — saved {saved} original asset(s) under {}", dir.display());
    Ok(())
}

fn cli_restore_original(card_hash: &str) -> anyhow::Result<()> {
    println!("=== Veyro CLI restore original ===");
    println!("card_hash = {card_hash}");
    warn_blocking_apps();

    let udid = first_udid()?;
    cleanup_books(&udid)?;
    println!("Keep iPhone UNLOCKED, screen ON. Open Books once if prompted.");
    println!("Writing backed-up original artwork...");

    flasher::restore_original_artwork(
        &udid,
        card_hash,
        |step, total, msg| println!("progress [{step}/{total}] {msg}"),
        |msg| println!("log: {msg}"),
    )?;

    println!("DONE — force-close Wallet on iPhone and reopen.");
    Ok(())
}

fn cli_passcode(
    theme_path: &str,
    telephony: Option<&str>,
    language: Option<&str>,
) -> anyhow::Result<()> {
    println!("=== Veyro CLI passcode ===");
    println!("theme     = {theme_path}");
    warn_blocking_apps();

    let udid = first_udid()?;
    cleanup_books(&udid)?;

    let forced = match telephony {
        Some("8") | Some("TelephonyUI-8") => Some("TelephonyUI-8"),
        Some("9") | Some("TelephonyUI-9") => Some("TelephonyUI-9"),
        Some("10") | Some("TelephonyUI-10") => Some("TelephonyUI-10"),
        _ => Some("TelephonyUI-10"),
    };
    let lang = language.unwrap_or("English");
    println!("telephony = {}", forced.unwrap_or("TelephonyUI-10"));
    println!("language  = {lang} (Bold Text caches included)");

    let theme = passthm::parse_passthm_file(std::path::Path::new(theme_path), forced, lang)?;
    println!("assets    = {}", theme.items.len());

    flasher::flash_passcode_theme(
        &udid,
        &theme.items,
        |step, total, msg| println!("progress [{step}/{total}] {msg}"),
        |msg| println!("log: {msg}"),
    )?;

    println!("DONE — lock the iPhone to view the keypad (Bold Text ON or OFF).");
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::probe_command;

    #[test]
    fn probe_requires_exact_cli_arguments() {
        let args = |values: &[&str]| {
            values
                .iter()
                .map(|value| (*value).to_owned())
                .collect::<Vec<_>>()
        };
        assert_eq!(probe_command(&args(&["veyro.exe", "--probe"])), Some(true));
        assert_eq!(probe_command(&args(&["veyro.exe", "--probe", "extra"])), Some(false));
        assert_eq!(probe_command(&args(&["veyro.exe", "--flash", "hash", "art.png"])), None);
    }
}
